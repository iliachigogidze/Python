Chapter 02: Pythonic Code
=========================

Test the code::

   make test
