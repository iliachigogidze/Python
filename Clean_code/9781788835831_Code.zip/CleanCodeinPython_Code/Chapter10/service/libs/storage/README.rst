Layer of Abstraction to the DB
==============================

This package is to be used as a library, imported from ``service``.

Instructions to create a test database are at ``db/README.rst``.
