libs/web
========

Python package that installs abstractions over the web application. This
package is being imported from the service, and it doesn't require extra setup
(no Docker image, etc.).