service/libs
============

Directory with the dependencies (libraries) for the main application.

- ``storage``: Python package that abstracts the database.
- ``web``: Python package that abstracts the web framework.
